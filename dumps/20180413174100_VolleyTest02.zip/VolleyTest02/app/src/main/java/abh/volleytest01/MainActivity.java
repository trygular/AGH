package abh.volleytest01;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.VolleyError;

import org.json.JSONObject;

import abh.aweb.AWEB;
import abh.aweb.resultInterface;

public class MainActivity extends AppCompatActivity {

    private Button b1, b2, b3, b4;
    private EditText t1, t2, etMulti1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = (Button) findViewById(R.id.b1);
        b2 = (Button) findViewById(R.id.b2);
        b3 = (Button) findViewById(R.id.b3);
        b4 = (Button) findViewById(R.id.b4);

        t1 = (EditText) findViewById(R.id.et1);
        t2 = (EditText) findViewById(R.id.et2);

        etMulti1 = (EditText) findViewById(R.id.etMulti1);



        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resultInterface ri = new resultInterface() {
                    @Override
                    public void Success(JSONObject response) {
                        Toast.makeText(getApplicationContext(), "S." + response.toString(), Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void Error(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "E." + error.toString(), Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void Exception(Exception e) {
                        Toast.makeText(getApplicationContext(), "X." + e.toString(), Toast.LENGTH_LONG).show();
                    }
                };
                AWEB web = new AWEB(getApplicationContext(), etMulti1, ri);
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });


    }
}
