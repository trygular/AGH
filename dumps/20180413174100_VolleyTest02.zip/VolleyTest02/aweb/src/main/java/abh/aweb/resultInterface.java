package abh.aweb;

import com.android.volley.VolleyError;
import org.json.JSONObject;

/**
 * Created by ADMIN on 13-04-2018.
 */
public interface resultInterface {

    void Success(JSONObject response);

    void Error(VolleyError error);

    void Exception(Exception e);
}