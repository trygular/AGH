package abh.aweb;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

/**
 * Created by ADMIN on 13-04-2018.
 */

public class AWEB
{
    private String url;
    public String aResponse;
    public AWEB(Context mContext, final EditText et, final resultInterface listener)
    {
        url = "https://shriganesh-a4d32.firebaseapp.com/package.json";
        try {
            RequestQueue queue = Volley.newRequestQueue(mContext);

            JsonObjectRequest jsonObj = new JsonObjectRequest(url, new JSONObject(),
            new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    listener.Success(response);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    listener.Error(error);
                }
            });

            queue.add(jsonObj);

        } catch(Exception e) {
            listener.Exception(e);
        }

    }
}
