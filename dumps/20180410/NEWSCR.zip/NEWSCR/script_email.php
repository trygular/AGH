<?php
	{
		
		$attchfilename = "attendencereport/".$_POST['filename'].".pdf";
		$frmdate = $_POST['frmdate'];
		$SMSmonth = date('m', strtotime($frmdate));
		$SMSyear = date('Y', strtotime($frmdate));
		
		require 'PHPMailer/class.phpmailer.php';

		$mail = new PHPMailer(); // create a new object
		$mail->IsSMTP(); // enable SMTP
		$mail->SMTPDebug = false; // debugging: 1 = errors and messages, 2 = messages only
		$mail->SMTPAuth = true; // authentication enabled
		$mail->SMTPSecure = 'tls'; // secure transfer enabled REQUIRED for Gmail
		$mail->Host = "smtp.tarunbharat.com";
		$mail->Port = 587; // or 587
		$mail->IsHTML(true);
		
		/* $mail->Username = "hrd.mgr@tarunbharat.com";
		$mail->Password = "intel123";
		$mail->SetFrom("hrd.mgr@tarunbharat.com");
		 */
		 $mail->Username = "edp.deptt@tarunbharat.com";
		$mail->Password = "intel123";
		$mail->SetFrom("edp.deptt@tarunbharat.com");
		$empcodeq="select empcode from StaffMaster where Name like'%".$_POST['empname']."%'";
		$resempcode = exequery($empcodeq);
		$rowempcode = fetch($resempcode);
		
		//$mail->Subject = "Purchase Order No.: ".$pono.". Date: ".$newDate;
		$mail->Subject = "Name: ".strtoupper($_POST['empname']).". ID No.: ".$rowempcode[0];
		$mail->Body = "This mail is regarding your absent report.So we request you to please clear your report as soon as possible,<br><br>From<br>H.R.D<br>Belgaum";

		$mail->AddAttachment($attchfilename);
		
		//$email = "pavandeshpande23@gmail.com";
		//$cemail = $mailid;
		$email = trim($_POST['mailid']);
		
		if($email!="")
		$mail->AddAddress($email,'0');
		if($cemail!="")
		$mail->AddAddress($cemail,'0');
		 
		if(!$mail->Send()){
			$ret = "Mailer Error: " . $mail->ErrorInfo;
		} 		
		else{
			$ret = "Mail Sent Successfully....";
		}
		//echo $email."</br>";
		echo $ret;
		die();
	}
?>