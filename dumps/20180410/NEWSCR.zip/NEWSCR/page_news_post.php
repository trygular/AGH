<?php
	include 'config.php';

	include("session.php");
	$session = new Session();

	$pro_id = "";

	if( !isset($_SESSION["user"]) ) {
		header("Location: page_profile.php");
	} else {
		$pro_id = $_SESSION["user"];
	}
?>
<!DOCTYPE html>
<html>
	<head>
        <script src="scripts/jquery-3.3.1.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/bootstrap.min.js"></script>
		<style>
		center { color:#FFF; }
		</style>
		
		<script>
			$(function () {
				$('.panel-collapse').on('show.bs.collapse', function (e) {
					$(e.target).closest('.panel').siblings().find('.panel-collapse').collapse('hide');
				});
			});
			$(document).ready(function() {
				$("#btnTabText").click();
				$("#viHeadline").focus();
			});
			
		</script>

	</head>
<body style="background: rgb(63, 65, 148);">

<?php

if( $_POST["submit"] == "Post News" ) {
	
	$queryInsertMain = "INSERT INTO main (type, headline, news, active, user) VALUES ('".$_POST["submit"]."', '".$_POST["txHeadline"]."', '".$_POST["txNews"]."', 0, '".$pro_id."')";
	$result = mysql_query($queryInsertMain, $con) or die("DB ERR: queryInsertMainTEXT");
	
	if($result)
		echo "<center>NEWS POSTED SUCCESSFULLY..</center>";
	else
		echo "<center>NEWS POSTING FAILED..</center>";

// NEWS
} else if( $_POST["submit"] == "Post Image News" ) {
	
	$path = "uploads/";
	$file_one = array($_FILES['imfImage1'], $path);
	$file_two = array($_FILES['imfImage2'], $path);
	$file_thr = array($_FILES['imfImage3'], $path);
	$file_fou = array($_FILES['imfImage4'], $path);
	$file_fiv = array($_FILES['imfImage5'], $path);
	
	$filePaths = uploadImage($file_one, $file_two, $file_thr, $file_fou, $file_fiv);
	
	$queryInsertMain = "INSERT INTO main (type, headline, news, file1, file2, file3, file4, file5, active, user)";
	$queryInsertMain .=" VALUES ";
	$queryInsertMain .="('".$_POST["submit"]."', '".$_POST["imHeadline"]."', '".$_POST["imNews"]."', '".$filePaths[0]."', '".$filePaths[1]."', '".$filePaths[2]."', '".$filePaths[3]."', '".$filePaths[4]."', 0, '".$pro_id."')";
	$result = mysql_query($queryInsertMain, $con) or die("DB ERR: queryInsertMainIMAGE");

	if($result)
		echo "<center>NEWS POSTED SUCCESSFULLY..</center>";
	else
		echo "<center>NEWS POSTING FAILED..</center>"; 
	
//IMAGE	
} else if( $_POST["submit"] == "Post Video News" ) {
	
	$path = "uploads/";
	$file_one = array($_FILES['vifVideo1'], $path);
	$file_two = array($_FILES['vifVideo2'], $path);
	$file_thr = array($_FILES['vifVideo3'], $path);
	$file_fou = array($_FILES['vifVideo4'], $path);
	$file_fiv = array($_FILES['vifVideo5'], $path);
	
	$filePaths = uploadVideo($file_one, $file_two, $file_thr, $file_fou, $file_fiv);
	
	$queryInsertMain = "INSERT INTO main (type, headline, news, file1, file2, file3, file4, file5, active, user)";
	$queryInsertMain .=" VALUES ";
	$queryInsertMain .="('".$_POST["submit"]."', '".$_POST["viHeadline"]."', '".$_POST["viNews"]."', '".$filePaths[0]."', '".$filePaths[1]."', '".$filePaths[2]."', '".$filePaths[3]."', '".$filePaths[4]."', 0, '".$pro_id."')";
	$result = mysql_query($queryInsertMain, $con) or die("DB ERR: queryInsertMainVIDEO");

	if($result)
		echo "<center>NEWS POSTED SUCCESSFULLY..</center>";
	else
		echo "<center>NEWS POSTING FAILED..</center>";

//VIDEO	
}

function uploadImage() {
    $num_args = func_num_args();
    $arg_list = func_get_args();
    
    $valReturn = false;
    $i = 0;
    $unlinkElement = array();
    foreach($arg_list as $key=>$value)
	{
		//echo "<br />val:".is_array($value) ." - Val[0]:".is_array($value[0]);
        if(is_array($value) AND is_array($value[0]))
		{
            if($value[0]['error'] == 0 AND isset($value[1]))
			{
                if($value[0]['size'] > 0 AND $value[0]['size'] < 500000) {
                    $typeAccepted = array("image/jpeg", "image/gif", "image/png");
                    if(in_array($value[0]['type'],$typeAccepted)) {    
                        $destination = $value[1];
                        if(isset($value[2])) {
                            $extension = substr($value[0]['name'] , strrpos($value[0]['name'] , '.') +1);
                            $destination .= (str_replace(" ","-",$value[2])).".".$extension;
                        } else {
                            $destination .= $value[0]['name'];
                        }
                        
                        if(move_uploaded_file($value[0]['tmp_name'],$destination)) {
                            $i++;
                            $unlinkElement[] = $destination;
                        }
                    }
                }
            }
        }
    }
    if($i == $num_args) {
        $valReturn = true;
		
    }/* else {
        foreach($unlinkElement as $value) {
            unlink($value);
        }
    }*/
    return $unlinkElement;
}

function uploadVideo() {
    $num_args = func_num_args();
    $arg_list = func_get_args();
    
    $valReturn = false;
    $i = 0;
    $unlinkElement = array();
    foreach($arg_list as $key=>$value)
	{
        if(is_array($value) AND is_array($value[0]))
		{
            if($value[0]['error'] == 0 AND isset($value[1]))
			{
                if($value[0]['size'] > 0 AND $value[0]['size'] < 900000)
				{
                    $typeAccepted = array("video/mp4");
                    if(in_array($value[0]['type'],$typeAccepted)) {    
                        $destination = $value[1];
                        if(isset($value[2])) {
                            $extension = substr($value[0]['name'] , strrpos($value[0]['name'] , '.') +1);
                            $destination .= (str_replace(" ","-",$value[2])).".".$extension;
                        } else {
                            $destination .= $value[0]['name'];
                        }
                        
                        if(move_uploaded_file($value[0]['tmp_name'],$destination)) {
                            $i++;
                            $unlinkElement[] = $destination;
                        }
                    }
                }
            }
        }
    }
    if($i == $num_args) {
        $valReturn = true;
		
    } /*else {
        foreach($unlinkElement as $value) {
            unlink($value);
        }
    }*/
    return $unlinkElement;
}

?>

<div class="container">
	<form action="page_news_post.php" method="post" enctype="multipart/form-data">
		<ul class="list-group" style="width:100%;">

				<li class="list-group-item">

					<div class="row panel">
						<div class="col-sm-12">
							<div role="tab" id="headingOne">
								<a class="collapsed" id="link0" href="page_news_list.php">
									<h6 id="btnTabMySub">MY SUBMISSION</h6>
								</a>
								<div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
	
								</div>  <!-- frmNewsList -->
							</div> <!-- tab 2 -->
						</div><!-- col --> 
					</div> <!-- row -->

				</li>
			
		<li class="list-group-item">
			<div class="row panel">
				<div class="col-sm-12">
					<div role="tab" id="headingTwo">
						<a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
							<h6 id="btnTabText">TEXT</h6>
						</a>
						<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">

			<!-- bs grid -->
			<div class="row">
				<div class="col-sm-12">Hedline<br /><input autocomplete="off" type="text" name="txHeadline" id="txHeadline" class="form-control" placeholder="News headline here..." /></div>
			</div>
			<div class="row">
				<div class="col-sm-12">Description<br /><textarea type="text" name="txNews" id="txNews" class="form-control" placeholder="News description here..."></textarea></div>
			</div>
			<div class="row">
				<div class="col-sm-12" style="text-align:right;"><br/><input autocomplete="off" type="submit" name="submit" class="btn btn-default" value="Post News"></div>
			</div>

						</div>  <!-- frmNewsList -->
					</div> <!-- tab 2 -->
				</div><!-- col --> 
			</div> <!-- row -->
		</li>

		<li class="list-group-item">
			<div class="row panel">
				<div class="col-sm-12">
					<div role="tab" id="headingThr">
						<a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThr" aria-expanded="false" aria-controls="collapseThr">
							<h6 id="btnTabImage">IMAGE</h6>
						</a>
						<div id="collapseThr" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThr">

			<!-- bs grid -->
			<div class="row">
				<div class="col-sm-12">Hedline<br /><input autocomplete="off" type="text" name="imHeadline" id="imHeadline" class="form-control" placeholder="News headline here..." /></div>
			</div>
			<div class="row">
				<div class="col-sm-12">Description<br /><textarea type="text" name="imNews" id="imNews" class="form-control" placeholder="News description here..."></textarea></div>
			</div>
			<div class="row">
				<div class="col-sm-12">
				Image 1<br /><input autocomplete="off" type="file" name="imfImage1" id="imfImage1" class="form-control" /><br />
				Image 2<br /><input autocomplete="off" type="file" name="imfImage2" id="imfImage2" class="form-control" /><br />
				Image 3<br /><input autocomplete="off" type="file" name="imfImage3" id="imfImage3" class="form-control" /><br />
				Image 4<br /><input autocomplete="off" type="file" name="imfImage4" id="imfImage4" class="form-control" /><br />
				Image 5<br /><input autocomplete="off" type="file" name="imfImage5" id="imfImage5" class="form-control" /><br />
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12" style="text-align:right;"><br /><input autocomplete="off" type="submit" name="submit" class="btn btn-default" value="Post Image News"></div>
			</div>
			
						</div>  <!-- frmImageList -->
					</div> <!-- tab 2 -->
				</div><!-- col --> 
			</div> <!-- row -->
		</li>

		<li class="list-group-item">

			<div class="row panel">
				<div class="col-sm-12">
					<div role="tab" id="headingFou">
						<a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFou" aria-expanded="false" aria-controls="collapseFou">
							<h6 id="btnTabText">VIDEO</h6>
						</a>
						<div id="collapseFou" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFou">

			<!-- bs grid -->
			<div class="row">
				<div class="col-sm-12">Hedline<br /><input autocomplete="off" type="text" name="viHeadline" id="viHeadline" class="form-control" placeholder="News headline here..." /></div>
			</div>
			<div class="row">
				<div class="col-sm-12">Description<br /><textarea type="text" name="viNews" id="viNews" class="form-control" placeholder="News description here..."></textarea></div>
			</div>
			<div class="row">
				<div class="col-sm-12">
				Video 1<br /><input autocomplete="off" type="file" name="vifVideo1" id="vifVideo1" class="form-control" /><br />
				Video 2<br /><input autocomplete="off" type="file" name="vifVideo2" id="vifVideo2" class="form-control" /><br />
				Video 3<br /><input autocomplete="off" type="file" name="vifVideo3" id="vifVideo3" class="form-control" /><br />
				Video 4<br /><input autocomplete="off" type="file" name="vifVideo4" id="vifVideo4" class="form-control" /><br />
				Video 5<br /><input autocomplete="off" type="file" name="vifVideo5" id="vifVideo5" class="form-control" /><br />
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12" style="text-align:right;"><br /><input autocomplete="off" type="submit" name="submit" class="btn btn-default" value="Post Video News"></div>
			</div>
						</div>  <!-- frmNewsList -->
					</div> <!-- tab 2 -->
				</div><!-- col --> 
			</div> <!-- row -->
		</li>
			
		</ul>
	</form>
</div>

</body>
<script>
	$(document).ready(funciton(){
		$("#link1").click();
	});
</script>
</html>