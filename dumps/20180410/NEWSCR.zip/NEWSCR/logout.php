<?php
include("session.php");
$session = new Session();

if(session_destroy())
{
    header("Location: page_profile.php");
}
?>
