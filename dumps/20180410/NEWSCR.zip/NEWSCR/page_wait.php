<html>
<head>
    <script src="scripts/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <style>
    img {
        position: absolute;
        top:0;
        bottom: 0;
        left: 0;
        right: 0;
        margin: auto;
        width: 400px;
        height: 400px;
    }
    </style>
</head>
<body>
    <img src="images\load.gif" />
</body>
<html>