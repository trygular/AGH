<?php
	include 'config.php';

	include("session.php");
	$session = new Session();

	$pro_id = "";

	if( !isset($_SESSION["user"]) ) {
		header("Location: page_profile.php");
	} else {
		$pro_id = $_SESSION["user"];
    }
?>
<!DOCTYPE html>
<html>
	<head>
        <script src="scripts/jquery-3.3.1.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/bootstrap.min.js"></script>
		<style>
		center { color:#FFF; }
		input[type=file] { visibility:hidden; }
		</style>
		
		<script>
			$(function () {
				$('.panel-collapse').on('show.bs.collapse', function (e) {
					$(e.target).closest('.panel').siblings().find('.panel-collapse').collapse('hide');
				});
			});
			$(document).ready(function() {
				$("#btnTabText").click();
				$("#viHeadline").focus();
			});
			
		</script>

	</head>
<body style="background: rgb(63, 65, 148);">

<?php

if( $_POST["submit"] == "Post News" ) {
	
	$queryInsertMain = "REPLACE INTO main (id, type, headline, news, active, user) VALUES ('".$_POST["newsid"]."', '".$_POST["submit"]."', '".$_POST["txHeadline"]."', '".$_POST["txNews"]."', 0, '".$pro_id."')";
	$result = mysql_query($queryInsertMain, $con) or die("DB ERR: queryInsertMainTEXT");
	
	if($result)
		echo "<center>NEWS UPDATED SUCCESSFULLY..</center>";
	else
		echo "<center>NEWS UPDATED FAILED</center>";

// NEWS
} else if( $_POST["submit"] == "Post Image News" ) {

	$path = "uploads/";
	$file_one = array($_FILES['imfImage1'], $path);
	$file_two = array($_FILES['imfImage2'], $path);
	$file_thr = array($_FILES['imfImage3'], $path);
	$file_fou = array($_FILES['imfImage4'], $path);
	$file_fiv = array($_FILES['imfImage5'], $path);
	
	$filePaths = uploadImage($file_one, $file_two, $file_thr, $file_fou, $file_fiv);
	
	$queryInsertMain = "REPLACE INTO main (id, type, headline, news, file1, file2, file3, file4, file5, active, user)";
	$queryInsertMain .=" VALUES ";
	$queryInsertMain .="('".$_POST["newsid"]."', '".$_POST["submit"]."', '".$_POST["imHeadline"]."', '".$_POST["imNews"]."', '".$filePaths[0]."', '".$filePaths[1]."', '".$filePaths[2]."', '".$filePaths[3]."', '".$filePaths[4]."', 0, '".$pro_id."')";
	$result = mysql_query($queryInsertMain, $con) or die("DB ERR: queryInsertMainIMAGE");

	if($result)
		echo "<center>NEWS UPDATED SUCCESSFULLY..</center>";
	else
		echo "<center>NEWS UPDATED FAILED</center>"; 

//IMAGE	
} else if( $_POST["submit"] == "Post Video News" ) {
	
	$path = "uploads/";
	$file_one = array($_FILES['vifVideo1'], $path);
	$file_two = array($_FILES['vifVideo2'], $path);
	$file_thr = array($_FILES['vifVideo3'], $path);
	$file_fou = array($_FILES['vifVideo4'], $path);
	$file_fiv = array($_FILES['vifVideo5'], $path);
	
	$filePaths = uploadVideo($file_one, $file_two, $file_thr, $file_fou, $file_fiv);
	
	$queryInsertMain = "REPLACE INTO main (id, type, headline, news, file1, file2, file3, file4, file5, active, user)";
	$queryInsertMain .=" VALUES ";
	$queryInsertMain .="('".$_POST["newsid"]."', '".$_POST["submit"]."', '".$_POST["viHeadline"]."', '".$_POST["viNews"]."', '".$filePaths[0]."', '".$filePaths[1]."', '".$filePaths[2]."', '".$filePaths[3]."', '".$filePaths[4]."', 0, '".$pro_id."')";
	$result = mysql_query($queryInsertMain, $con) or die("DB ERR: queryInsertMainVIDEO");

	if($result)
		echo "<center>NEWS UPDATED SUCCESSFULLY..</center>";
	else
		echo "<center>NEWS UPDATED FAILED</center>";

//VIDEO	
} else if( $_POST["submit"] == "Delete" ) {
	$queryDeleteMain = "DELETE FROM main WHERE id='".$_POST["newsid"]."' ";
	$result = mysql_query($queryDeleteMain, $con) or die("DB ERR: queryDeleteMain");

	if($result)
		echo "<center>NEWS DELETED SUCCESSFULLY..</center>";
	else
		echo "<center>NEWS DELETED FAILED</center>";
//DELETE
} 

function uploadImage() {
    $num_args = func_num_args();
    $arg_list = func_get_args();
    
    $valReturn = false;
    $i = 0;
    $unlinkElement = array();
    foreach($arg_list as $key=>$value)
	{
		//echo "<br />val:".is_array($value) ." - Val[0]:".is_array($value[0]);
        if(is_array($value) AND is_array($value[0]))
		{
            if($value[0]['error'] == 0 AND isset($value[1]))
			{
                if($value[0]['size'] > 0 AND $value[0]['size'] < 500000) {
                    $typeAccepted = array("image/jpeg", "image/gif", "image/png");
                    if(in_array($value[0]['type'],$typeAccepted)) {    
                        $destination = $value[1];
                        if(isset($value[2])) {
                            $extension = substr($value[0]['name'], strrpos($value[0]['name'] , '.') +1);
                            $destination .= (str_replace(" ","-",$value[2])).".".$extension;
                        } else {
                            $destination .= $value[0]['name'];
                        }
                        
                        if(move_uploaded_file($value[0]['tmp_name'],$destination)) {
                            $i++;
                            $unlinkElement[] = $destination;
                        }
                    }
                }
            }
        }
    }
    if($i == $num_args) {
        $valReturn = true;
		
    }/* else {
        foreach($unlinkElement as $value) {
            unlink($value);
        }
    }*/
    return $unlinkElement;
}

function uploadVideo() {
    $num_args = func_num_args();
    $arg_list = func_get_args();
    
    $valReturn = false;
    $i = 0;
    $unlinkElement = array();
    foreach($arg_list as $key=>$value)
	{
        if(is_array($value) AND is_array($value[0]))
		{
            if($value[0]['error'] == 0 AND isset($value[1]))
			{
                if($value[0]['size'] > 0 AND $value[0]['size'] < 900000)
				{
                    $typeAccepted = array("video/mp4");
                    if(in_array($value[0]['type'],$typeAccepted)) {    
                        $destination = $value[1];
                        if(isset($value[2])) {
                            $extension = substr($value[0]['name'] , strrpos($value[0]['name'] , '.') +1);
                            $destination .= (str_replace(" ","-",$value[2])).".".$extension;
                        } else {
                            $destination .= $value[0]['name'];
                        }
                        
                        if(move_uploaded_file($value[0]['tmp_name'],$destination)) {
                            $i++;
                            $unlinkElement[] = $destination;
                        }
                    }
                }
            }
        }
    }
    if($i == $num_args) {
        $valReturn = true;
		
    } /*else {
        foreach($unlinkElement as $value) {
            unlink($value);
        }
    }*/
    return $unlinkElement;
}

$newsid = $_GET["newsid"];
$news_headline = "";
$news_news = "";
$news_type = "";

$news_file1 = "";
$news_file2 = "";
$news_file3 = "";
$news_file4 = "";
$news_file5 = "";

$news_file1Chk = false;
$news_file2Chk = false;
$news_file3Chk = false;
$news_file4Chk = false;
$news_file5Chk = false;


// identify user posts
if($newsid != "" || $newsid != 0)
{
    $qrySelect = "SELECT * FROM main WHERE id='".$newsid."' ";
    $result = mysql_query($qrySelect, $con);

    if ( mysql_num_rows($result) > 0 )
    {
        // output data of each row
        while($row = mysql_fetch_assoc($result))
        {
            $news_headline = $row["headline"];
            $news_news = $row["news"];
			$news_type = $row["type"];
			
			$news_file1 = str_replace("uploads/", "", $row["file1"]);
			$news_file2 = str_replace("uploads/", "", $row["file2"]);
			$news_file3 = str_replace("uploads/", "", $row["file3"]);
			$news_file4 = str_replace("uploads/", "", $row["file4"]);
			$news_file5 = str_replace("uploads/", "", $row["file5"]);
			
        }
    } else {
        $news_headline = "No news found.";
        $news_news = "Post a news and select a specific news to edit.";
        $news_type = "";
        // header("Location : page_news_post.php");
    }

} else {
    $news_headline = "No news is selected.";
    $news_news = "Please select a news from news list.<br /><a href='page_news_list.php'>Go to News list.</a>" ;
    $news_type = "";
}
?>


<div class="container">
	<form action="page_news_edit.php" method="post" enctype="multipart/form-data">
		<input type="hidden" id="newsid" name="newsid" value="<?echo $newsid;?>" />
		<ul class="list-group" style="width:100%;">

        <li class="list-group-item">
            <div class="row panel">
                <div class="col-sm-12">
                    <div role="tab" id="headingOne">
                        <a class="collapsed" id="link0" href="page_news_list.php">
                            <h6 id="btnTabMySub">MY SUBMISSION</h6>
                        </a>
                        <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">

                        </div>  <!-- frmNewsList -->
                    </div> <!-- tab 2 -->
                </div><!-- col --> 
            </div> <!-- row -->

        </li>

<?php if($news_type == 'Post News') { ?>

		<li class="list-group-item">
			<div class="row panel">
				<div class="col-sm-12">
					<div role="tab" id="headingTwo">
						<a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
							<h6 id="btnTabText">TEXT</h6>
						</a>
						<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">

			<!-- bs grid -->
			<div class="row">
				<div class="col-sm-12">Hedline<br /><input autocomplete="off" type="text" name="txHeadline" id="txHeadline" class="form-control" placeholder="News headline here..." value="<?php echo $news_headline; ?>" /></div>
			</div>
			<div class="row">
				<div class="col-sm-12">Description<br /><textarea type="text" name="txNews" id="txNews" class="form-control" placeholder="News description here..."><?php echo $news_news; ?></textarea></div>
			</div>
			<div class="row">
				<div class="col-sm-12" style="text-align:right;">
		<br/>
		<input type="submit" name="submit" class="btn btn-danger" id="btnNewsDelete" value="Delete">
		<input type="submit" name="submit" class="btn btn-default" value="Post News"></div>
			</div>

						</div>  <!-- frmNewsList -->
					</div> <!-- tab 2 -->
				</div><!-- col --> 
			</div> <!-- row -->
		</li>

<?php } else if($news_type == 'Post Image News') { ?>

		<li class="list-group-item">
			<div class="row panel">
				<div class="col-sm-12">
					<div role="tab" id="headingThr">
						<a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThr" aria-expanded="false" aria-controls="collapseThr">
							<h6 id="btnTabImage">IMAGE</h6>
						</a>
						<div id="collapseThr" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThr">

			<!-- bs grid -->
			<div class="row">
				<div class="col-sm-12">Hedline<br /><input autocomplete="off" type="text" name="imHeadline" id="imHeadline" class="form-control" placeholder="News headline here..." value="<?php echo $news_news; ?>" /></div>
			</div>
			<div class="row">
				<div class="col-sm-12">Description<br /><textarea type="text" name="imNews" id="imNews" class="form-control" placeholder="News description here..."><?php echo $news_headline; ?></textarea></div>
			</div>
			<div class="row">
				<div class="col-sm-12">

				<br />
				<label for="imfImage1" id="imfImage1Up" class="btn btn-primary">Update Image 1</label>
				<label id="imfImage1ChkLab" for="imfImage1Chk" class="btn btn-primary">
				<input type="checkbox" id="imfImage1Chk" name="imfImage1Chk" mytyp="img" myid="1" /> Remove Image 1 </label>
				<input type="file" name="imfImage1" id="imfImage1" class="form-control"/>
				
				<label for="imfImage2" id="imfImage2Up" class="btn btn-primary">Update Image 2</label> 
				<label id="imfImage2ChkLab" for="imfImage2Chk" class="btn btn-primary">
				<input type="checkbox" id="imfImage2Chk" name="imfImage2Chk" value="<?echo $news_file2Chk;?>" mytyp="img" myid="2" /> Remove Image 2 </label>
				<input type="file" name="imfImage2" id="imfImage2" class="form-control"/>

				<label for="imfImage3" id="imfImage3Up" class="btn btn-primary">Update Image 3</label> 
				<label id="imfImage3ChkLab" for="imfImage3Chk" class="btn btn-primary">
				<input type="checkbox" id="imfImage3Chk" name="imfImage3Chk" value="<?echo $news_file3Chk;?>" mytyp="img" myid="3" /> Remove Image 3 </label>
				<input type="file" name="imfImage3" id="imfImage3" class="form-control"/>

				<label for="imfImage4" id="imfImage4Up" class="btn btn-primary">Update Image 4</label> 
				<label id="imfImage4ChkLab" for="imfImage4Chk" class="btn btn-primary">
				<input type="checkbox" id="imfImage4Chk" name="imfImage4Chk" value="<?echo $news_file4Chk;?>" mytyp="img" myid="4" /> Remove Image 4 </label>
				<input type="file" name="imfImage4" id="imfImage4" class="form-control"/>

				<label for="imfImage5" id="imfImage5Up" class="btn btn-primary">Update Image 5</label> 
				<label id="imfImage5ChkLab" for="imfImage5Chk" class="btn btn-primary">
				<input type="checkbox" id="imfImage5Chk" name="imfImage5Chk" value="<?echo $news_file5Chk;?>" mytyp="img" myid="5" /> Remove Image 5 </label>
				<input type="file" name="imfImage5" id="imfImage5" class="form-control"/>

				</div>
			</div>
			<div class="row">
				<div class="col-sm-12" style="text-align:right;">
		<br/>
		<input type="submit" name="submit" class="btn btn-danger" id="btnNewsDelete" value="Delete">
		<input type="submit" name="submit" class="btn btn-default" value="Post Image News"></div>
			</div>
			
						</div>  <!-- frmImageList -->
					</div> <!-- tab 2 -->
				</div><!-- col --> 
			</div> <!-- row -->
		</li>

<?php } else if($news_type == 'Post Video News') { ?>

		<li class="list-group-item">

			<div class="row panel">
				<div class="col-sm-12">
					<div role="tab" id="headingFou">
						<a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFou" aria-expanded="false" aria-controls="collapseFou">
							<h6 id="btnTabText">VIDEO</h6>
						</a>
						<div id="collapseFou" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFou">

			<!-- bs grid -->
			<div class="row">
				<div class="col-sm-12">Hedline<br /><input autocomplete="off" type="text" name="viHeadline" id="viHeadline" class="form-control" placeholder="News headline here..." value="<?php echo $news_headline; ?>"/></div>
			</div>
			<div class="row">
				<div class="col-sm-12">Description<br /><textarea type="text" name="viNews" id="viNews" class="form-control" placeholder="News description here..."><?php echo $news_news; ?></textarea></div>
			</div>
			<div class="row">
				<div class="col-sm-12">
				<br />
				<label for="vifVideo1" id="vifVideo1Up" class="btn btn-primary">Update Video 1</label>
				<label id="vifVideo1ChkLab" for="vifVideo1Chk" class="btn btn-primary"><input type="checkbox" id="vifVideo1Chk" name="vifVideo1Chk" mytyp="vid" myid="1" /> Remove Video 1 </label>
				<input type="file" name="vifVideo1" id="vifVideo1" class="form-control" />
				
				<label for="vifVideo2" id="vifVideo2Up" class="btn btn-primary">Update Video 2</label> 
				<label id="vifVideo2ChkLab" for="vifVideo2Chk" class="btn btn-primary"><input type="checkbox" id="vifVideo2Chk" name="vifVideo2Chk" mytyp="vid" myid="2" /> Remove Video 2 </label>
				<input type="file" name="vifVideo2" id="vifVideo2" class="form-control" />

				<label for="vifVideo3" id="vifVideo3Up" class="btn btn-primary">Update Video 3</label> 
				<label id="vifVideo3ChkLab" for="vifVideo3Chk" class="btn btn-primary"><input type="checkbox" id="vifVideo3Chk" name="vifVideo3Chk" mytyp="vid" myid="3" /> Remove Video 3 </label>
				<input type="file" name="vifVideo3" id="vifVideo3" class="form-control" />

				<label for="vifVideo4" id="vifVideo4Up" class="btn btn-primary">Update Video 4</label> 
				<label id="vifVideo4ChkLab" for="vifVideo4Chk" class="btn btn-primary"><input type="checkbox" id="vifVideo4Chk" name="vifVideo4Chk" mytyp="vid" myid="4" /> Remove Video 4 </label>
				<input type="file" name="vifVideo4" id="vifVideo4" class="form-control" />

				<label for="vifVideo5" id="vifVideo5Up" class="btn btn-primary">Update Video 5</label> 
				<label id="vifVideo5ChkLab" for="vifVideo5Chk" class="btn btn-primary"><input type="checkbox" id="vifVideo5Chk" name="vifVideo5Chk" mytyp="vid" myid="5" /> Remove Video 5 </label>
				<input type="file" name="vifVideo5" id="vifVideo5" class="form-control" />

				</div>
			</div>
			<div class="row">
				<div class="col-sm-12" style="text-align:right;">
		<br/>
		<input type="submit" name="submit" class="btn btn-danger" id="btnNewsDelete" value="Delete">
		<input type="submit" name="submit" class="btn btn-default" value="Post Video News"></div>
			</div>
						</div>  <!-- frmNewsList -->
					</div> <!-- tab 2 -->
				</div><!-- col --> 
			</div> <!-- row -->
		</li>

<?php } else if($news_type == '' || $news_type == '0' || $news_type == null) { ?>
        
		<li class="list-group-item">
			<div class="row panel">
				<div class="col-sm-12">
					<div role="tab" id="headingTwo">
						<a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
							<h6 id="btnTabText"><?php echo $news_headline; ?></h6>
						</a>
						<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                        <?php echo $news_news; ?>
						</div>  <!-- frmNewsList -->
					</div> <!-- tab 2 -->
				</div><!-- col --> 
			</div> <!-- row -->
		</li>

<?php } ?>

		</ul>
	</form>
</div>

</body>
<script>
	$(document).ready(function(){
		
		$("#btnNewsDelete").submit(function( event ) {
			if (!confirm("This news will be deleted.<br/>Are you sure you want to delete this news.")) {		// validation failed
				event.preventDefault();
			}
		});
		
		$("input[type='checkbox']").change(function(){
			// alert( "#imfImage" + $(this).attr("myid") + "-" + $(this).val() );
				
			if( $(this).attr("mytyp") == "img" ) {
				if(this.checked) {
					$( "#imfImage"+$(this).attr("myid") ).val();
					$( "#imfImage"+$(this).attr("myid")+"Up" ).hide(1000);
				} else {
					$( "#imfImage"+$(this).attr("myid")+"Up" ).show(1000);
				}
			} else if( $(this).attr("mytyp") == "vid" ) {
				if(this.checked) {
					$( "#vifVideo"+$(this).attr("myid") ).val();
					$( "#vifVideo"+$(this).attr("myid")+"Up" ).hide(1000);
				} else {
					$( "#vifVideo"+$(this).attr("myid")+"Up" ).show(1000);
				}
			}
		});

		$('#imfImage1Chk').prop("checked", <?php if($news_file1 == "") { echo "true"; } else { echo "false"; } ?> );
		$('#imfImage2Chk').prop("checked", <?php if($news_file2 == "") { echo "true"; } else { echo "false"; } ?> );
		$('#imfImage3Chk').prop("checked", <?php if($news_file3 == "") { echo "true"; } else { echo "false"; } ?> );
		$('#imfImage4Chk').prop("checked", <?php if($news_file4 == "") { echo "true"; } else { echo "false"; } ?> );
		$('#imfImage5Chk').prop("checked", <?php if($news_file5 == "") { echo "true"; } else { echo "false"; } ?> );

		$('#imfImage1Chk').click();
		$('#imfImage2Chk').click();
		$('#imfImage3Chk').click();
		$('#imfImage4Chk').click();
		$('#imfImage5Chk').click();

		
	});
</script>
</html>