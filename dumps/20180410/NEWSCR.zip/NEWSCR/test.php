<?php
	include 'config.php';
		
	include("session.php");
	$session = new Session();

?>

<html>
<head>
    <script src="scripts/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    
</head>
<body style="background: rgb(63, 65, 148);">

	<div class="container">
        <ul class="list-group">
            <li class="list-group-item">
                <div class="row form-group">
                    <div class="col-xs-5"><a href="page_news_post.php">News Post</a></div>
                </div>
                <div class="row form-group">
                    <div class="col-xs-5"><a href="page_news_list.php">My Submission</a></div>
                </div>
                <div class="row form-group">
                    <div class="col-xs-5"><a href="page_news_setting.php">Setting</a></div>
                </div>
                <div class="row form-group">
                    <div class="col-xs-5"><a href="logout.php">Logout</a></div>
                </div>
            </li>
        </ul>
	</div>
</body>

</html>