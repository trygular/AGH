<?php

include("config.php");

if( $_POST['Action'] == "SMS_Send")
{
    //Your authentication key
    $authKey = "1eb155da72b53245fb32b05532b4de";

    //Sender ID,While using route4 sender id should be 6 characters long.
    $senderId = "TARUNB";

    //Multiple mobiles numbers separated by comma
    $mobileNumber = $_POST['mobileno'];

    $number_rand = mt_rand(100000,999999); 

    $msg = $number_rand." is your OTP for registeration at Tarun Bharat NEWSCR app.";

    //Your message to send, Add URL encoding here.
    $message = urlencode($msg);

    $unicode=0;

    //Define route 
    $route = 4;

    //Prepare you post parameters
    $postData = array(
        'authkey' => $authKey,
        'mobiles' => $mobileNumber,
        'message' => $message,
        'sender' => $senderId, 
        'route' => $route,
        'unicode' => $unicode
    );

    $sql0 = "INSERT INTO otp (mobile, message, sender, route, unicode, otp) VALUES ('".$mobileNumber."', '".$message."', '".$senderId."', '".$route."', '".$unicode."', ".$number_rand.") ";
	if($result0 = mysql_query($sql0, $con))
	{
        //echo $postData;
        
        //API URL
        $url = "http://sms.belgaumit.com/sendhttp.php";
        
        // init the resource
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData
            //,CURLOPT_FOLLOWLOCATION => true
        ));

        //Ignore SSL certificate verification
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        //get response
        $output = curl_exec($ch);

        //Print error if any
        if(curl_errno($ch))
        {
            echo "FAILED"; // echo 'error:' . curl_error($ch);
        } else {
            echo "SUCCESS";
        }

        curl_close($ch);

        // echo $output;
        
        /*echo "SUCCESS";*/
    } else {
        echo "FAIL";
    }
    die();
}



?>

<!--
<html>
<form action='sms.php' method='post'>
<center>
<table width='50%'>
<tr><td colspan=2 align='center' ><font size='7'>Tarun Bharat </font><font color='brown' size='7'>SMS Portal</font> </td></tr>
<tr><td colspan=2 align='center'><img src='images/sms123.jpg' width=50% height=50%></img></td></tr>
<tr><td width='50%' align='right'><font color='brown' size='4'> SMS Type : </td><td width='50%'>
<select name='smstype' >
<option value='0'>English</option>
<option value='1'>Marathi Unicode</option>
</select>

</td></tr>
<tr><td width='50%' align='right'><font color='brown' size='4'> SMS Service : </td><td width='50%'>
<select name='smsservice' >
<option value='TARUNB'>TARUN BHARAT</option>
<option value='LOKHRD'>LOKMANYA </option>
</select>

</td></tr>
<tr><td width='50%' align='right'>Paste Your Mobile No : </td><td width='50%'><textarea type='text' name='mobileno' id='mobileno' rows=3 cols=40></textarea><br><br></td></tr>

<tr><td align='right'>Paste Your Message : </td><td><textarea type='text' name='msg' id='msg' rows=3 cols=40></textarea> <br><br></td></tr>
<tr><td colspan=2 align='center'><input type='submit' name='Action' value='Send_SMS'></td></tr>
</form>
</html>
-->