<?php
	include 'config.php';
		
	include("session.php");
	$session = new Session();

    $timediff = 3000; // 30 min
    $timecurr = date('YmdHis', time());
    $_SESSION["time"] = 20180412161300; // date('YmdHis', time());
    if( isset($_SESSION["time"]) && $_SESSION["time"] == "" ) {	// is expired
        if(($timecurr - $_SESSION["time"]) > $timediff)
            header("Location: index.html");
    }
?>
