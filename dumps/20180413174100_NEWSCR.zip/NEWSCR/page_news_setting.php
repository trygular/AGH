<?php
	include 'config.php';

	include("session.php");
	$session = new Session();

?>

<html>
<head>
    <script src="scripts/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <style>
		html, body, table, tr {
			height: 100%;
			width: 100%;
		}
		center { color:#FFF; }
	</style>

	<!-- style for collapse other tabs -->
	<script>
	$(function () {
        $('.panel-collapse').on('show.bs.collapse', function (e) {
			$(e.target).closest('.panel').siblings().find('.panel-collapse').collapse('hide');
        });
    });

	$(document).ready(function(){
		msgHide();
		$("#btnTabLogin").click();
	});

	function msgHide()
	{
		$("#txMessage").html("");
		$("#txMessage").hide();
	}

	function msgShow(msg)
	{
		$("#txMessage").html(msg);
		$("#txMessage").show();
	}
	</script>
</head>

<?php

$pro_id = "";
$row = "";
if( isset($_SESSION["user"]) )
{
	$sql = "SELECT * FROM login WHERE user_id='".$_SESSION["user"]."' ";
	$result = mysql_query($sql, $con);
	$row = mysql_fetch_row($result);
	$pro_id = $row[0];
	//$pro_name = $row[3];
	//$pro_mobi = $row[4];
}

if( $_POST["submit"] == "Update" )
{
	$sql = "UPDATE login SET password='".$_POST["tpPass"]."' WHERE user_id='".$_SESSION["user"]."' AND password='".$_POST["tpOld"]."' ";
	$result = mysql_query($sql, $con);
	if($result)
	{
		echo "<center>Password update successful.</center>";
	} else {
		echo "<center>Password not updates.</center>".mysql_error();
	}
}

?>

<body style="background: rgb(63, 65, 148);">

<!-- common logo -->
<?php include_once("common_logo.php"); ?>

	<div id="txMessage" style="width:100%;height:auto;position:fixed;top:0px;left:0px;z-index: 1000;" class="form-control">JavaScript not enabled on your browser.</div>
	<div class="container">
		
					<ul class="list-group">

						<!-- common menu -->
						<?php include_once("common_menu.php"); ?>

						<li class="list-group-item">

						<div class="row panel">
							<div class="col-sm-12">
								<div role="tab" id="headingTwo">
									<a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
										<h6 id="btnTabProfile">Profile</h6>
									</a>
									<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">

										<div class="row form-group">
											<div class="col-sm-2">Name</div>
											<div class="col-sm-10"><? echo $row[3] ?></div>
										</div> 
										<div class="row form-group">
											<div class="col-sm-2">Username</div>
											<div class="col-sm-10"><? echo $row[1] ?></div>
										</div>
										<div class="row form-group">
											<div class="col-sm-2">Email</div>
											<div class="col-sm-10"><? echo $row[5] ?></div>
										</div>
										<div class="row form-group">
											<div class="col-sm-2">Mobile</div>
											<div class="col-sm-10"><? echo $row[4] ?></div>
										</div> 
										<div class="row form-group">
											<div class="col-sm-2">City</div>
											<div class="col-sm-10"><? echo $row[6] ?></div>
										</div> 
										
										<div class="row form-group">
											<div class="col-sm-12" style="text-align:right;">
											</div>
										</div>

									</div>
								</div> <!-- tab 2 -->
							</div><!-- col --> 
						</div> <!-- row -->

						<div class="row panel">
							<div class="col-sm-12">
								<div role="tab" id="headingOne">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
										<h6 id="btnTabPassChange">Change Password</h6>
									</a>
									<div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">

										<form name="frmPassChange" id="frmPassChange" action="page_news_setting.php" method="POST">
											<div class="row">
												<div class="col-sm-4"></div>
												<div class="col-sm-4"></div>
												<div class="col-sm-4"></div>
											</div>
											<div class="row form-group">
												<div class="col-sm-12">Old Password<br /><input type="password" name="tpOld" id="tpOld" class="form-control" placeholder="Old Password" /></div>
											</div>
											<div class="row form-group">
												<div class="col-sm-12">New Password<br /><input type="password" name="tpPass" id="tpPass" class="form-control" placeholder="New Password" /></div>
											</div>
											<div class="row form-group">
												<div class="col-sm-12">Confirm Password<br /><input type="password" name="tpCon" id="tpCon" class="form-control" placeholder="Confir Password" /></div>
											</div> 
											<div class="row">
												<div class="col-sm-12" style="text-align:right;"><input autocomplete="off" type="submit" id="btnPassUpdate" class="btn btn-default" name="submit" value="Update"></div>
											</div>
										</form>

									</div>  <!-- frmLogin -->
								</div> <!-- tab 1 -->
							</div><!-- col --> 
						</div> <!-- row -->

						</li>
					</ul>
	</div>
</body>

<script>
	$(document).ready(function(){
		
		$('#btnTabProfile').click();
		
	});
</script>

</html>