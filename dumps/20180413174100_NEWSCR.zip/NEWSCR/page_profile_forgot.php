<?php
	include 'config.php';
	
?>

<html>
<head>
    <script src="scripts/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <style>
		html, body, table, tr {
			height: 100%;
			width: 100%;
		}

		center { color:#FFF; }
	</style>

	<!-- style for collapse other tabs -->
	<script>
	$(function () {
        $('.panel-collapse').on('show.bs.collapse', function (e) {
			$(e.target).closest('.panel').siblings().find('.panel-collapse').collapse('hide');
        });
    });

	$(document).ready(function(){
		msgHide();
		$("#btnTabLogin").click();
	});

	function msgHide()
	{
		$("#txMessage").html("");
		$("#txMessage").hide();
	}

	function msgShow(msg)
	{
		$("#txMessage").html(msg);
		$("#txMessage").show();
	}
	</script>
</head>
<body style="background: rgb(63, 65, 148);">

<!-- common logo -->
<?php include_once("common_logo.php"); ?>

<?php

$flag_show = 0;

if($_POST["submit"] == "Reset Password")
{
	$sqlGetOTP = "SELECT otp FROM otp WHERE mobile='".$_POST["txMobi"]."' ORDER BY id desc";
	$resultGetOTP = mysql_query($sqlGetOTP, $con);
	if (mysql_num_rows($resultGetOTP) != 0)
	{
		$row = mysql_fetch_row($resultGetOTP);

		$otp_inp = $_POST["txOtp"];
		$otp_sms = $row[0];
		
		// check if input opt matches with sms otp
		if($otp_inp == $otp_sms)
		{
			// otp validated - update password
			$flag_show = 1;
		} else {
			echo "<center>Wrong OTP entered..!</center>";
			$flag_show = 0;
		}
	} else {
		echo "<center>Mobile no. not exists..!</center>";
		$flag_show = 0;
	}
}

if($_POST["submit"] == "Update")
{
	$sql = "UPDATE login SET password='".$_POST["tpPass"]."' WHERE mobile='".$_POST["tpMobile"]."' ";
	$result = mysql_query($sql, $con);
	if($result)
	{
		echo "<center>Password update successful.</center>";
		echo "<script>setTimeout(function(){ window.location = 'page_profile.php'; }, 3000);</script>";
	} else {
		echo "<center>Password not updates.</center>".mysql_error();
	}
}

?>
	<div id="txMessage" style="width:100%;height:auto;position:fixed;top:0px;left:0px;z-index: 1000;" class="form-control">JavaScript not enabled on your browser.</div>
	<div class="container">
	
	<?php
		if($flag_show == 0) {			// --  Reset PASSWORD with OTP
	?>
						
		<!-- common menu -->
		<?php include_once("common_menu.php"); ?>

		<ul class="list-group">
			<li class="list-group-item">

			<div class="row panel">
				<div class="col-sm-12">
					<div role="tab" id="headingTwo">
						<a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
							<h6 id="btnTabOtpVerify">Reset password</h6>
						</a>
						<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">

							<form name="frmOtpVerify" id="frmOtpVerify" action="page_profile_forgot.php" method="POST">
								
								<div class="row form-group">
									<div class="col-sm-12">Mobile<br /><input autocomplete="off" type="number" name="txMobi" id="txMobi" class="form-control" placeholder="Mobile" /></div>
								</div> 
								<div class="row form-group">
									<div class="col-sm-6">
										<input type="button" name="btnOtp" id="btnOtp" class="btn btn-primary" value="Send OTP" />
									</div>
									<div class="col-sm-6">
										<input type="number" name="txOtp" id="txOtp" class="form-control" value="" placeholder="Enter OTP sent to mobile" />
									</div>
								</div> 
								<div class="row form-group">
									<div class="col-sm-12" style="text-align:right;">
									<input autocomplete="off" type="submit" class="btn btn-default" name="submit" value="Reset Password" />
									</div>
								</div>
							</form>

						</div>  <!-- frmOtpVerify -->
					</div> <!-- tab 2 -->
				</div><!-- col --> 
			</div> <!-- row -->

			</li>
		</ul>
				
	<?php
		} else if($flag_show == 1) {
			// USER is here after OPT VERIFIED
	?>
			
		<ul class="list-group">
			<li class="list-group-item">
			<div class="row panel">
				<div class="col-sm-12">
					<div role="tab" id="headingOne">
						<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
							<h6 id="btnTabPassChange">Change Password</h6>
						</a>
						<div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">

							<form name="frmPassChange" id="frmPassChange" action="page_profile_forgot.php" method="POST">
								<div class="row form-group">
									<div class="col-sm-12"><input type="hidden" name="tpMobile" id="tpMobile" class="form-control" placeholder="Old Password" readonly value="<?echo $_POST["txMobi"];?>" /></div>
								</div>
								<div class="row form-group">
									<div class="col-sm-12">New Password<br /><input type="password" name="tpPass" id="tpPass" class="form-control" placeholder="New Password" /></div>
								</div>
								<div class="row form-group">
									<div class="col-sm-12">Confirm Password<br /><input type="password" name="tpCon" id="tpCon" class="form-control" placeholder="Confir Password" /></div>
								</div> 
								<div class="row">
									<div class="col-sm-12" style="text-align:right;"><input autocomplete="off" type="submit" id="btnPassUpdate" class="btn btn-default" name="submit" value="Update"></div>
								</div>
							</form>

						</div>  <!-- frmPassChange -->
					</div> <!-- tab 1 -->
				</div><!-- col --> 
			</div> <!-- row -->
			</li>
		</ul>

	<?php
		}
	?>
			
	</div>
</body>
<script>

	$(document).ready(function(){
		$("#btnTabOtpVerify").click();
		$("#btnTabPassChange").click();
	});

	$("#btnOtp").click(function(){

		if(	$("#txMobi").val().length == 0 )
		{
			msgShow("Invalid mobile number.");
			$("#txMobi").val("").focus();
		} else if( $("#txMobi").val().length != 10 )
		{
			msgShow("Enter 10 digit mobile number.");
			$("#txMobi").val("").focus();
		} else if( $("#txMobi").val().length == 10 )
		{
			msgHide();
			
			// lock mobile input
			$("#txMobi").prop("readonly", true);
			
			//disable btn send otp
			$('#btnOtp').prop('disabled', true);

		var jqxhr = $.post("page_sms.php", { Action: "SMS_USER", mobileno: $("#txMobi").val() })
			.done(function(resp) {
				if(resp == "SUCCESS")
				{
					msgShow("OTP sent to +91-" + $("#txMobi").val() );
					$('#txOtp').val("").prop("disabled", false).focus();
				} else if(resp == "FAILED") {
					//unlock mobile input
					$("#txMobi").removeAttr("readonly");

					//enable btn send otp
					$('#btnOtp').prop("disabled", false);

					$('#txOtp').prop("disabled", true);

					msgShow("OTP sending failed..");
				} else if(resp == "FAIL1") {
					//unlock mobile input
					$("#txMobi").removeAttr("readonly");

					//enable btn send otp
					$('#btnOtp').prop("disabled", false);

					$('#txOtp').prop("disabled", true);

					msgShow("User mobile not registered..");
				} else if(resp == "FAIL2") {
					//unlock mobile input
					$("#txMobi").removeAttr("readonly");

					//enable btn send otp
					$('#btnOtp').prop("disabled", false);

					$('#txOtp').prop("disabled", true);

					msgShow("OTP Generating failed, Try again later..");
				}
			})
			.fail(function() {
				msgShow("OTP request failed..");
			})
			.always(function() {
				
			});
		}
	});

	$("#txOtp").change(function(){
		if( $(this).val().length > 6 ) {
			msgShow("OTP can be 6 digit only..");
			$(this).val("").focus();
		} else if( $(this).val().length == 6 ) {
			$("#txCity").focus();
		}
	});
</script>

</html>