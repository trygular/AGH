<style>
    div.commonWait {
        position:absolute;
        max-width:45%;
        max-height:45%;
        top:50%;
        left:50%;
        overflow:visible;
    }
    img.commonWaitImg {
        position:relative;
        max-width:100%;
        max-height:100%;
        margin-top:-50%;
        margin-left:-50%;
    }
</style>

<div class="commonWait"><img class="commonWaitImg" src="images\load.gif" /></div>

<script>
    $('.commonWait').hide();
    function waitShow() { $('.commonWait').show(); }
    function waitHide() { $('.commonWait').hide(); }
</script>