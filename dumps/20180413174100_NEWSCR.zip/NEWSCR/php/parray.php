<?php

header('Content-Type: application/json; charset=utf-8');

// array for JSON response
$response = array();

// successfully updated
array_push($response, "{'name': 'defauName', 'pass': 'DefaultPass'}");
array_push($response, "{'name': '".$_POST['username']."', 'pass': '".$_POST['password']."'}");

// echoing JSON response
echo json_encode($response);

?>