<?php

$response = array("lati" => $_GET['lati'], 'longi' => $_GET['longi'] );
echo json_encode($response);

?>