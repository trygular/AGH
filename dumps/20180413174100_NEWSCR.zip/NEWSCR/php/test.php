<?php

$phonenumber = $_POST["phonenumber"];

?>