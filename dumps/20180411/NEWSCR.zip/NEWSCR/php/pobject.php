<?php

class Person
{
    private $name;
    private $pass;
    function Person()
    {
        $this->name = "test";
        $this->pass = "testing";
    }

    function toStr()
    {
        return "{name:'".$this->name."', pass:'".$this->pass."'}";
    }

}

header('Content-Type: application/json; charset=utf-8');

// array for JSON response
$response = new Person();

// echoing JSON response
echo json_encode($response);

?>