<style>
    .mCenter { text-align:center; }
</style>

<li class="list-group-item">
    <div class="row form-group">
        <div class="col-sm-6 mCenter"><a href="index.html">HOME</a></div>
        <div class="col-sm-6 mCenter"><a href="page_profile.php">PROFILE</a></div>
    </div>
</li>