<?php
	include 'config.php';

	include("session.php");
	$session = new Session();

	$pro_id = "";

	if( isset($_SESSION["user"]) ) {
		$pro_id = $_SESSION["user"];
	}
?>
<html>
<head>
    <script src="scripts/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <style>
		html, body, table, tr {
			height: 100%;
			width: 100%;
		}
		center { color:#FFF; }
		.imgSize { width:90%; height:90%; }
	</style>

	<script>
		
		function msgHide()
		{
			$("#txMessage").html("");
			$("#txMessage").hide();
		}

		function msgShow(msg)
		{
			$("#txMessage").html("<center><img src='" + msg +"' /></center><br /><a class='btn btn-default float-right' onclick=' msgHide(); '>Close</a>");
			$("#txMessage").show();
		}
		
		$(function () {
			$('.panel-collapse').on('show.bs.collapse', function (e) {
				$(e.target).closest('.panel').siblings().find('.panel-collapse').collapse('hide');
			});
		});
		
		$(document).ready(function() {
			$("#btnTabNewsList").click();
			msgHide();

			$('body').on('click','img',function(){ msgShow( $(this).attr("src")); });
		});
	</script>

</head>
<body style="background: rgb(63, 65, 148);">

<!-- common logo -->
<?php include_once("common_logo.php"); ?>

<div id="txMessage" style="width:100%;height:auto;position:fixed;top:0px;left:0px;z-index: 1000;" class="form-control">JavaScript not enabled on your browser.</div>
<div class="container">

				<ul class="list-group">

					<!-- common menu -->
					<?php include_once("common_menu.php"); ?>

					<li class="list-group-item">

					<div class="row panel">
						<div class="col-sm-12">
							<div role="tab" id="headingTwo">
								<a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
									<h6 id="btnTabNewsList">News List</h6>
								</a>
								<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
	<ul class="list-group">
	<?php
		$perpage = 10;
		$pages_count = ceil($count / $perpage);

		$qrySelect = "SELECT SQL_CALC_FOUND_ROWS * FROM main "; // LIMIT ".(int)($page - 1)." ".(int)$perpage;

		// identify user posts
		if($pro_id != "" || $pro_id != 0)
			$qrySelect .= " WHERE user = '".$pro_id."'";

		$result = mysql_query($qrySelect, $con);

		if ( mysql_num_rows($result) > 0) {
			// output data of each row
			while($row = mysql_fetch_assoc($result))
			{
				if($row["headline"] != null && $row["news"] != null)
				{
					if( isset($_SESSION["user"]) ) {
						$disp_btn_edit = "<a class='btn btn-default float-right' id='btn_news_edit' href='./page_news_edit.php?newsid=".$row["id"]."'>Edit</a>";
					}

					echo "<li class=\"list-group-item\"><h5><b>" . $row["headline"]. "</b>".$disp_btn_edit."</h5><p>" . $row["news"]. "<br/>";
				
					if($row["type"] == "Post Image News")
					{
						if($row["file1"] != null)
						{
							echo "<br/><img src='" . $row["file1"]. "' class='img-circle' width='70' height='70'	/>";
							if($row["file2"] != null)
							{
								echo " <img src='" . $row["file2"]. "' class='img-circle' width='70' height='70'  />";
								if($row["file3"] != null)
								{
									echo " <img src='" . $row["file3"]. "' class='img-circle' width='70' height='70'  />";
									if($row["file4"] != null)
									{
										echo " <img src='" . $row["file4"]. "' class='img-circle' width='70' height='70'  />";
										if($row["file5"] != null)
										{
											echo " <img src='" . $row["file5"]. "' class='img-circle' width='70' height='70'  />";
										}
									}
								}
							}
						}
					} else if($row["type"] == "Post Video News") {
						if($row["file1"] != null)
						{
							echo "<br/><a href='" . $row["file1"]. "'>View Video 1</a>";
							if($row["file2"] != null)
							{
								echo "<br/><a href='" . $row["file2"]. "'>View Video 2</a>";
								if($row["file3"] != null)
								{
									echo "<br/><a href='" . $row["file3"]. "'>View Video 3</a>";
									if($row["file4"] != null)
									{
										echo "<br/><a href='" . $row["file4"]. "'>View Video 4</a>";
										if($row["file5"] != null)
										{
											echo "<br/><a href='" . $row["file5"]. "'>View Video 5</a>";
										}
									}
								}
							}
						}
					}
					echo "</p></li>";
				}
			}
		} else {
			// user post is empty
		?>

			<li class="list-group-item">News bin is empty.<br /> <a href="page_news_post.php">Create first post.</a></li>

		<?
		}
		mysql_close();
	?>
	</ul>
								</div>  <!-- frmNewsList -->
							</div> <!-- tab 2 -->
						</div><!-- col --> 
					</div> <!-- row -->

				</ul>
			
			
		
</div>
</body>
</html>