package abh.volleytest01;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private Button b1, b2, b3, b4;
    private EditText t1, t2, etMulti1;

    private String url = "http://circulation.tbdnet/NEWSCR/tests/index.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = (Button) findViewById(R.id.b1);
        b2 = (Button) findViewById(R.id.b2);
        b3 = (Button) findViewById(R.id.b3);
        b4 = (Button) findViewById(R.id.b4);

        t1 = (EditText) findViewById(R.id.et1);
        t2 = (EditText) findViewById(R.id.et2);

        etMulti1 = (EditText) findViewById(R.id.etMulti1);

        // POST
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RequestQueue queue = Volley.newRequestQueue(getApplicationContext());  // this = context
                StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>()
                        {
                            @Override
                            public void onResponse(String response) {
                                // response
                                // Log.d("Response", response);
                                etMulti1.setText(response);
                            }
                        },
                        new Response.ErrorListener()
                        {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                // error
                                // Log.d("Error.Response", response);
                                etMulti1.setText(error.toString());
                            }
                        }
                ) {
                    @Override
                    protected Map<String, String> getParams()
                    {
                        Map<String, String>  params = new HashMap<String, String>();
                        params.put("name", "SHRI GANESH");

                        return params;
                    }
                };

                queue.add(postRequest);
            }
        });

        // GET
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    RequestQueue queue = Volley.newRequestQueue(getApplicationContext());  // this = context
                    // prepare the Request

                    JsonObjectRequest getRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                            new Response.Listener<JSONObject>()
                            {
                                @Override
                                public void onResponse(JSONObject response) {
                                    // display response
                                    // Log.d("Response", response.toString());
                                    etMulti1.setText(response.toString());
                                }
                            },
                            new Response.ErrorListener()
                            {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    // String response;
                                    // Log.d("Error.Response", response);
                                    etMulti1.setText(error.toString());
                                }
                            }
                    );

                    // add it to the RequestQueue
                    queue.add(getRequest);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        // PUT
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try
                {
                    RequestQueue queue = Volley.newRequestQueue(getApplicationContext());  // this = context
                    StringRequest putRequest = new StringRequest(Request.Method.PUT, url,
                            new Response.Listener<String>()
                            {
                                @Override
                                public void onResponse(String response) {
                                    // response
                                    // Log.d("Response", response);
                                    etMulti1.setText(response);
                                }
                            },
                            new Response.ErrorListener()
                            {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    // error
                                    // Log.d("Error.Response", response);
                                    etMulti1.setText(error.toString());
                                }
                            }
                    ) {

                        @Override
                        protected Map<String, String> getParams()
                        {
                            Map<String, String>  params = new HashMap<String, String> ();
                            params.put("name", "Alif");
                            return params;
                        }

                    };

                    queue.add(putRequest);
                } catch (Exception e) {
                    e.printStackTrace();;
                }
            }
        });

        // DELETE
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    RequestQueue queue = Volley.newRequestQueue(getApplicationContext());  // this = context
                    StringRequest dr = new StringRequest(Request.Method.DELETE, url,
                            new Response.Listener<String>()
                            {
                                @Override
                                public void onResponse(String response) {
                                    // response
                                    //Toast.makeText($this, response, Toast.LENGTH_LONG).show();
                                    etMulti1.setText(response);
                                }
                            },
                            new Response.ErrorListener()
                            {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    // error.

                                }
                            }
                    );
                    queue.add(dr);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });


    }
}
